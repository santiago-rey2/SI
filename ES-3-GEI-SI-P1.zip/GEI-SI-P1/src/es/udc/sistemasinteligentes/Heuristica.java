package es.udc.sistemasinteligentes;

public abstract class Heuristica {
    public abstract float evalua(Estado e);
}
